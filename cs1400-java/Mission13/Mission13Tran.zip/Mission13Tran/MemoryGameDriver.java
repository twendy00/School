public class MemoryGameDriver {
    
    public static void main(String[] args) {

        MemoryGame mc = new MemoryGame();
    }

}